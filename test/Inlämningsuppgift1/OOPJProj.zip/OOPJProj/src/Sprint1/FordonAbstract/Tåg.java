package Sprint1.FordonAbstract;

public class Tåg extends Fordon {

        private int antalVagnar;


        public Tåg(int antalVagnar, int hastighet, int vikt) {
            super(hastighet, vikt);
            this.antalVagnar = antalVagnar;
        }

    public int getAntalVagnar() {
        return antalVagnar;
    }

    public void setAntalVagnar(int antalVagnar) {
        this.antalVagnar = antalVagnar;
    }

    public void kopplaVagn(int nyttAntalVagnar) {
            antalVagnar= nyttAntalVagnar;
        }
    @Override
    public void printMe() {
        System.out.println("Tåg - Antal vagnar: "+ getAntalVagnar()+ ", Hastighet: " +
                getHastighet() + ", Vikt: " + getVikt());
    }


}
