package Sprint1.FordonAbstract;

public class Cykel extends Fordon {
    int antalVäxlar;
    int växelJustNu;

    public Cykel(int antalVäxlar, int växelJustNu, int hastighet, int vikt) {
        super(hastighet, vikt);
        this.antalVäxlar = antalVäxlar;
        this.växelJustNu = växelJustNu;
    }

    public int getAntalVäxlar() {
        return antalVäxlar;
    }

    public void setAntalVäxlar(int antalVäxlar) {
        this.antalVäxlar = antalVäxlar;
    }

    public int getVäxelJustNu() {
        return växelJustNu;
    }

    public void setVäxelJustNu(int växelJustNu) {
        this.växelJustNu = växelJustNu;
    }

    public void växla(int nyVäxel){
        växelJustNu = nyVäxel;
    }

    @Override
    public void printMe() {
        System.out.println("Cykel - Antal växlar: "+ getAntalVäxlar()+ ", Nuvarande växel: " +
                getVäxelJustNu() + ", Hastighet: " + getHastighet() + ", Vikt: " + getVikt() );
    }


}
