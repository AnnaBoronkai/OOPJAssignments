package Sprint1.FordonAbstract;

public class Båt extends Fordon {
    private double dödvikt;


    public Båt(double dödvikt,boolean sväng, int hastighet, int vikt) {
        super(hastighet, vikt);
        this.dödvikt = dödvikt;

    }

    public double getDödvikt() {
        return dödvikt;
    }

    public void setDödvikt(double dödvikt) {
        this.dödvikt = dödvikt;
    }

    @Override
    public void printMe() {
        System.out.println("Båt - Dödvikt: "+ getDödvikt() + ", Hastighet: " + getHastighet() +
                ", Vikt: " + getVikt() );
    }

}
