package Sprint1.FordonAbstract;

import java.util.ArrayList;
import java.util.List;

public class Huvudprogram {

    private List <Fordon> fordonsArrayLista = new ArrayList<>();
    private Fordon [] fordonsArray = new Fordon[4];

    public void huvudprogram(){
        Bil minBil = new Bil(6, 2, 30, 1500);
        Båt minBåt = new Båt (200, true, 50, 100);
        Tåg mittTåg = new Tåg (8, 150, 20000);
        Cykel minCykel = new Cykel(11, 9, 20, 15);

        minBil.printMe();
        minBåt.printMe();
        mittTåg.printMe();
        minCykel.printMe();

        fordonsArrayLista.add(minBil);
        fordonsArrayLista.add(minBåt);
        fordonsArrayLista.add(mittTåg);
        fordonsArrayLista.add(minCykel);

        System.out.println();

       for (Fordon fordon : fordonsArrayLista) {
           fordon.printMe();


       }
        fordonsArray [0] = new Bil (6, 2, 30, 1500);
        fordonsArray [1] = new Båt(200, true, 50, 100);
        fordonsArray [2] = new Tåg(8, 150, 20000);
        fordonsArray [3] = new Cykel(11, 9, 20, 15);

        System.out.println();

        for (Fordon fordon : fordonsArray) {
            fordon.printMe();
        }
    }

    public static void main(String[] args) {
       Huvudprogram h = new Huvudprogram();

       h.huvudprogram();

    }
}
