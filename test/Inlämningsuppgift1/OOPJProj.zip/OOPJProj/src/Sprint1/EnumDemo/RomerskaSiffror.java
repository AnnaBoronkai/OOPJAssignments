package Sprint1.EnumDemo;

public enum RomerskaSiffror {

            I (1, "Ett"),
            V (5, "Fem"),
            X (10, "Tio"),
            L (50,"Femtio"),
            C (100, "Hundra"),
            D (500, "Fem hundra"),
            M (1000, "Tusen");

            public int nrVal;

            public String stringVal;

            private RomerskaSiffror (int i, String s){
                nrVal = i;
                stringVal = s;
            }



}
