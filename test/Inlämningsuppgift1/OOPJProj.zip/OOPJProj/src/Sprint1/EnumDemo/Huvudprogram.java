package Sprint1.EnumDemo;

public class Huvudprogram {
    public static void main(String[] args) {


        for (RomerskaSiffror r : RomerskaSiffror.values()){
            System.out.println(r + " " + r.nrVal + " " + r.stringVal);
        }
    }
}
