package Sprint1.Interface;

public class Huvudprogram {

    private void printViaPrintable (Printable fordon) {
        fordon.printMe();
    }

    public void huvudprogram(){
        Bil bil = new Bil(5,4,100,1400);
        Båt båt = new Båt (1000, true, 60, 300);
        Tåg tåg = new Tåg(9, 160, 1000000);
        Cykel cykel = new Cykel(21, 30,12);

    printViaPrintable(bil);
    printViaPrintable(båt);
    printViaPrintable(tåg);
    printViaPrintable(cykel);

    }
    public static void main(String[] args) {
        Huvudprogram h = new Huvudprogram();
        h.huvudprogram();
    }
}
