package Sprint1.Interface;

import Sprint1.Övning2.Fordon;

public class Cykel extends Fordon implements Printable {
    int antalVäxlar;
    int växelJustNu;



    public Cykel(int antalVäxlar, int hastighet, int vikt) {
        super(hastighet, vikt);
        this.antalVäxlar = antalVäxlar;
    }

    public void växla(int nyVäxel){
        växelJustNu = nyVäxel;
    }

    public void printMe() {
        System.out.println("Bil - Antal växlar: "+ antalVäxlar + ", Nuvarande växel: " +
                antalVäxlar + ", Hastighet: " + getHastighet() + ", Vikt: " + getVikt() );
    }

}
