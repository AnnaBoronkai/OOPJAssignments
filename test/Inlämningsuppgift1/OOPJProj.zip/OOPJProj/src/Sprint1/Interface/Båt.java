package Sprint1.Interface;

import Sprint1.Övning2.Fordon;

public class Båt extends Fordon implements Printable {
    private double dödvikt;
    private boolean sväng;

    public Båt(double dödvikt,boolean sväng, int hastighet, int vikt) {
        super(hastighet, vikt);
        this.dödvikt = dödvikt;
        this.sväng = true;
    }

    public Båt(boolean sväng) {
        this.sväng = sväng;
    }

    public void printMe() {
        System.out.println("Båt - Dödvikt: "+ dödvikt + ", Hastighet: " + getHastighet() +
                ", Vikt: " + getVikt() );
    }
}

