package Sprint1.Interface;

import Sprint1.Övning2.Fordon;

public class Bil extends Fordon implements Printable {

    private int  antalVäxlar;
    private int växelJustNu;



    public Bil(int antalVäxlar, int växelJustNu, int hastighet, int vikt) {
        super(hastighet, vikt);
        this.antalVäxlar = antalVäxlar;
        this.växelJustNu = växelJustNu;
    }
    public void växla(int nyVäxel){
        växelJustNu =nyVäxel;
    }

    public void printMe() {
        System.out.println("Bil - Antal växlar: "+ antalVäxlar + ", Nuvarande växel: " +
                antalVäxlar + ", Hastighet: " + getHastighet() + ", Vikt: " + getVikt() );
    }

}

