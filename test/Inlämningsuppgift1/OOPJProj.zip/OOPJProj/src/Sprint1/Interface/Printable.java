package Sprint1.Interface;

public interface Printable {
     void printMe();
}
