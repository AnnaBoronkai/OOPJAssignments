package Sprint1.Interface;

import Sprint1.Övning2.Fordon;

public class Tåg extends Fordon implements Printable {
    private int antalVagnar;


    public Tåg(int antalVagnar, int hastighet, int vikt) {
        super(hastighet, vikt);
        this.antalVagnar = antalVagnar;
    }

    public void kopplaVagn(int nyttAntalVagnar) {
        antalVagnar= nyttAntalVagnar;
    }

    public void printMe() {
        System.out.println("Tåg - Antal vagnar: "+ antalVagnar+ ", Hastighet: " +
                getHastighet() + ", Vikt: " + getVikt());
    }


}

