package Sprint1.GitDemo2;

public class Klass2 {
    private String animal = "Katt";
    private String animal2 = "hund";
}
