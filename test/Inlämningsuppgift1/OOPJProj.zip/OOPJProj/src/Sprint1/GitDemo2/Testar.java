package Sprint1.GitDemo2;

public class Testar {

    public String hälsning = "hej!!!!!";
}
