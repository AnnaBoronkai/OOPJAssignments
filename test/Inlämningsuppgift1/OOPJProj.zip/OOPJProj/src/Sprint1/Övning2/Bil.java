package Sprint1.Övning2;

public class Bil extends Fordon {

    private int  antalVäxlar;
    private int växelJustNu;



    public Bil(int antalVäxlar, int växelJustNu, int hastighet, int vikt) {
        super(hastighet, vikt);
        this.antalVäxlar = antalVäxlar;
        this.växelJustNu = växelJustNu;
    }
    public void växla(int nyVäxel){
        växelJustNu =nyVäxel;
    }


}
