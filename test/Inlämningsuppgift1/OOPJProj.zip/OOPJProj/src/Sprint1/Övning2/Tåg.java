package Sprint1.Övning2;

public class Tåg extends Fordon {
    private int antalVagnar;


    public Tåg(int antalVagnar, int hastighet, int vikt) {
        super(hastighet, vikt);
        this.antalVagnar = antalVagnar;
    }

    public void kopplaVagn(int nyttAntalVagnar) {
        antalVagnar= nyttAntalVagnar;
    }
}
