package Sprint1.Övning2;

public class Båt extends Fordon {
    private double dödvikt;
    private boolean sväng;

    public Båt(double dödvikt,boolean sväng, int hastighet, int vikt) {
        super(hastighet, vikt);
        this.dödvikt = dödvikt;
        this.sväng = true;
    }

    public Båt(boolean sväng) {
        this.sväng = sväng;
    }
}
