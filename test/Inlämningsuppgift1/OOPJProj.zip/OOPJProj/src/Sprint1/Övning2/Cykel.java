package Sprint1.Övning2;

public class Cykel extends Fordon {
    int antalVäxlar;
    int växelJustNu;



    public Cykel(int antalVäxlar, int hastighet, int vikt) {
        super(hastighet, vikt);
        this.antalVäxlar = antalVäxlar;
    }

    public void växla(int nyVäxel){
        växelJustNu = nyVäxel;
    }

}
