package Sprint1.Skola;

import java.sql.Struct;

public class Huvudprogram {

    public static void printClassList(Kurs course) {
        System.out.println("Kursnamn: " + course.getCourseName());
        System.out.println("Lärare: " + course.getTeacher().getName());
        System.out.println("Studenter: ");
        for (Student student : course.getStudents()) {
            System.out.println("-" + student.getName());
        }
    }

    public void huvudprogram() {

        Kurs programmering1 = new Kurs("Programmering 1", null, new Student[2]);
        Kurs programmering2 = new Kurs("Programmering 2", null, new Student[3]);
        Kurs svenska1 = new Kurs("Svenska 1", null, new Student[5]);


        Student anna = new Student("Anna Andersson", "Andergatan 9",
                "Anna.Andersson@hotmail.com", new Kurs[2]);

        Student henrik = new Student("Henrik Hansson", "Hemvägen 8",
                "Henrik.Hansson@gmail.com", new Kurs[2]);

        Student linda = new Student("Linda Larsson", "Larsbodavägen 36",
                "linda.lars@hmail.com", new Kurs[0]);

        Student niklas = new Student("Niklas Nilsson", "Nynäsvägen 6",
                "Niklas.Nilsson@hmail.com", new Kurs[0]);

        Student viktor = new Student("Viktor Vikholm", "Viknägatan 3",
                "virre.viks@hmail.com", new Kurs[0]);


        Lärare håkan = new Lärare("Håkan Olofsson", "Arbottnavägen 18",
                "hakan.olof@gmail.com", new Kurs[0]);

        Lärare birgitta = new Lärare("Birgitta Holm", "Lundagatan 11",
                "Birgitta.Holm", new Kurs[0]);

        programmering1.setTeacher(håkan);
        programmering2.setTeacher(håkan);
        svenska1.setTeacher(birgitta);

        programmering1.setStudents(new Student[] {anna, henrik});
        programmering2.setStudents(new Student[]{linda,niklas, viktor});
        svenska1.setStudents(new Student[]{anna, henrik, linda, niklas, viktor});

        System.out.println();
        printClassList(svenska1);
        System.out.println();
        printClassList(programmering1);
        System.out.println();
        printClassList(programmering2);

    }

    public static void main(String[] args) {

        Huvudprogram h = new Huvudprogram();
        h.huvudprogram();

    }
}
