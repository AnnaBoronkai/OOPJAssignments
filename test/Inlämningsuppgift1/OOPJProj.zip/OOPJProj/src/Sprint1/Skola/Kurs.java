package Sprint1.Skola;

public class Kurs {

    private String courseName;
    private Lärare teacher;
    private Student [] students;

    public Kurs(String courseName, Lärare teacher, Student[] students) {
        this.courseName = courseName;
        this.teacher = teacher;
        this.students = students;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public Lärare getTeacher() {
        return teacher;
    }

    public void setTeacher(Lärare teacher) {
        this.teacher = teacher;
    }

    public Student [] getStudents() {
        return students;
    }

    public void setStudents(Student [] students) {
        this.students = students;
    }



}
