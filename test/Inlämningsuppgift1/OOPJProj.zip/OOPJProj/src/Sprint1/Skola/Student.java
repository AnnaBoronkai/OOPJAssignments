package Sprint1.Skola;

public class Student extends Person {

    private Kurs [] enrolledCourses;

    public Student(String name, String address, String email, Kurs[] enrolledCourses) {
        super(name, address, email);
        this.enrolledCourses = enrolledCourses;
    }

    public Kurs[] getEnrolledCourses() {
        return enrolledCourses;
    }

    public void setEnrolledCourses(Kurs[] enrolledCourses) {
        this.enrolledCourses = enrolledCourses;
    }
}
