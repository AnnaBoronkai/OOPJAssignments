package Sprint1.Skola;

public class Lärare extends Person {

    private Kurs [] teachingCourses;

    public Lärare(String name, String address, String email, Kurs[] teachingCourses) {
        super(name, address, email);
        this.teachingCourses = teachingCourses;
    }

    public Kurs[] getTeachingCourses() {
        return teachingCourses;
    }

    public void setTeachingCourses(Kurs[] teachingCourses) {
        this.teachingCourses = teachingCourses;
    }
}
