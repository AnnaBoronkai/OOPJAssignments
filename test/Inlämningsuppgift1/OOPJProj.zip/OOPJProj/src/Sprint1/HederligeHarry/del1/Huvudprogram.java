package Sprint1.HederligeHarry.del1;

public class Huvudprogram {

    public void huvudprogram(){
        BilAnnons bilAnnons = new BilAnnons(200000, "Läcker Audi till salu",
                "En Audi A3", 2018, 3000, "röd", true);
        HusvagnsAnnons husvagnsAnnons = new HusvagnsAnnons(120000, "Praktisk husvagn!",
                "En KABE ametist", 2009, 8000, true, 4);
        MotorcykelAnnons motorcykelAnnons = new MotorcykelAnnons(40000, "Glidarhoj till salu!",
                "En Yamaha YZF-R1", 2000, 5000, 800, "kedja");

        System.out.println();
        bilAnnons.getAnnonsText();
        System.out.println();
        husvagnsAnnons.getAnnonsText();
        System.out.println();
        motorcykelAnnons.getAnnonsText();

    }


    public static void main(String[] args) {
        Huvudprogram h = new Huvudprogram();
        h.huvudprogram();


    }
}
