package Sprint1.HederligeHarry.del1;

public class MotorcykelAnnons extends FordonsAnnons{
    private int motorVolym;
    private String drivTyp;

    public MotorcykelAnnons(int pris, String rubrik, String beskrivning, int årsmodell,
                            int antalMil, int motorVolym, String drivTyp) {
        super(pris, rubrik, beskrivning, årsmodell, antalMil);
        this.motorVolym = motorVolym;
        this.drivTyp = drivTyp;
    }

    public int getMotorVolym() {
        return motorVolym;
    }

    public void setMotorVolym(int motorVolym) {
        this.motorVolym = motorVolym;
    }

    public String getDrivTyp() {
        return drivTyp;
    }

    public void setDrivTyp(String drivTyp) {
        this.drivTyp = drivTyp;
    }
    @Override
    public void getAnnonsText() {
        System.out.println(getRubrik());
        System.out.println(getBeskrivning() + ", årsmodell " + getÅrsmodell() + ", till det otroliga priset "
                + getPris() + "! Har gått " + getAntalMil() + " mil, " + getMotorVolym() + " cm3, drivtyp "
                + getDrivTyp() + ".");

    }
}
