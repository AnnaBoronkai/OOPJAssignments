package Sprint1.HederligeHarry.del2;

public interface Revenuable {
    void calculateRevenue();
}
