package Sprint1.HederligeHarry.del2;

public class BilAnnons extends FordonsAnnons implements Publishable {

    private String märke;
    private String modell;
    private String färg;

    private boolean vinterdäck;

    public BilAnnons(int pris, String rubrik, String beskrivning, int årsmodell, int antalMil,
                     String färg, boolean vinterdäck) {
        super(pris, rubrik, beskrivning, årsmodell, antalMil);
        this.färg = färg;
        this.vinterdäck = vinterdäck;
    }


    public String getFärg() {
        return färg;
    }

    public void setFärg(String färg) {
        this.färg = färg;
    }

    public boolean isVinterdäck() {
        return vinterdäck;
    }

    public void setVinterdäck(boolean vinterdäck) {
        this.vinterdäck = vinterdäck;
    }
    public void printHeader(){
        System.out.println(getRubrik()+ getPris());
    }

     public void printCompleteAd(){
        System.out.println(getBeskrivning() + ", årsmodell " + getÅrsmodell() +
                ", " + getFärg());
        if (vinterdäck) {
            System.out.println("Utrustad med vinterdäck. Har gått " + getAntalMil() + " mil, " +
                    getPris() + " kr. En perfekt bil för den händige till ett fantastiskt pris!");
        } else {
            System.out.println("Utrustad med vinterdäck. Har gått " + getAntalMil() + " mil, " +
                    getPris() + " kr. En perfekt bil för den händige till ett fantastiskt pris!");
        }
    }

    public void calculateRevenue(){
        double momsDeduction = 0.75;
        double profit = getPris() * momsDeduction;
        System.out.println("Harrys vinst för bilen är " + profit + " kr.");
    }
}


