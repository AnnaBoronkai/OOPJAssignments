package Sprint1.HederligeHarry.del2;

public interface Publishable {

    void printHeader();

    void printCompleteAd();
}
