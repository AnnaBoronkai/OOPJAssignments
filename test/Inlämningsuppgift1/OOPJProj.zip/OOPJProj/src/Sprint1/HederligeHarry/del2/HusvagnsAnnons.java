package Sprint1.HederligeHarry.del2;

public class HusvagnsAnnons extends FordonsAnnons {
    private boolean dusch;
    private int antalBäddar;

    public HusvagnsAnnons(int pris, String rubrik, String beskrivning, int årsmodell,
                          int antalMil, boolean dusch, int antalBäddar) {
        super(pris, rubrik, beskrivning, årsmodell, antalMil);
        this.dusch = dusch;
        this.antalBäddar = antalBäddar;
    }

    public boolean isDusch() {
        return dusch;
    }

    public void setDusch(boolean dusch) {
        this.dusch = dusch;
    }

    public int getAntalBäddar() {
        return antalBäddar;
    }

    public void setAntalBäddar(int antalBäddar) {
        this.antalBäddar = antalBäddar;
    }

    public void printHeader() {
        System.out.println(getRubrik() + getPris());
    }

    public void printCompleteAd() {
        System.out.println("En husvagn lagom till semestern? Här har du en " + getBeskrivning() +
                ", årsmodell " + getÅrsmodell() + ". Har körts " + getAntalMil() + " mil, utrustad med " + getAntalBäddar() + " bäddar. "
                + getPris() + " kr.");
        if (dusch) {
            System.out.println("Har dusch.");
        }
    }
    public void calculateRevenue(){
        double momsDeduction = 0.75;
        double profit = getPris() * momsDeduction;
        System.out.println("Harrys vinst för husvagnen är " + profit + " kr.");
    }
}