package Sprint1.SkolaArrayList;
import java.util.*;

public class Student extends Person {


    private ArrayList<Kurs> enrolledCourses;

    public Student(String name, String address, String email, ArrayList<Kurs> enrolledCourses) {
        super(name, address, email);
        this.enrolledCourses = enrolledCourses;
    }

    public ArrayList<Kurs> getEnrolledCourses() {
        return enrolledCourses;
    }

    public void setEnrolledCourses(ArrayList<Kurs> enrolledCourses) {
        this.enrolledCourses = enrolledCourses;
    }
}
