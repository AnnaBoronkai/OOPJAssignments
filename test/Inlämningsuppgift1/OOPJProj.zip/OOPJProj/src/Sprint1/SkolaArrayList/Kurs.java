package Sprint1.SkolaArrayList;
import java.util.*;


    public class Kurs {

        private String courseName;
        private Lärare teacher;
        private ArrayList<Student> students;

        public Kurs(String courseName, Lärare teacher, ArrayList<Student> students) {
            this.courseName = courseName;
            this.teacher = teacher;
            this.students = students;
        }

        public String getCourseName() {
            return courseName;
        }

        public void setCourseName(String courseName) {
            this.courseName = courseName;
        }

        public Lärare getTeacher() {
            return teacher;
        }

        public void setTeacher(Lärare teacher) {
            this.teacher = teacher;
        }

        public ArrayList<Student> getStudents() {
            return students;
        }

        public void setStudents(ArrayList<Student> students) {
            this.students = students;
        }



    }
