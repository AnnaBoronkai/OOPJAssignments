package Sprint1.SkolaArrayList;

import java.util.*;

public class Huvudprogram {

    public static void printClassList(Kurs course) {
        System.out.println("Kursnamn: " + course.getCourseName());
        System.out.println("Lärare: " + course.getTeacher().getName());
        System.out.println("Studenter: ");
        for (Student student : course.getStudents()) {
            System.out.println("-" + student.getName());
        }
    }

    public void huvudprogram() {

        ArrayList<Student> students = new ArrayList<>();
        ArrayList<Kurs> courses = new ArrayList<>();

        Kurs programmering1 = new Kurs("Programmering 1", null, new ArrayList<>());
        Kurs programmering2 = new Kurs("Programmering 2", null, new ArrayList<>());
        Kurs svenska1 = new Kurs("Svenska 1", null, new ArrayList<>());


        Student anna = new Student("Anna Andersson", "Andergatan 9",
                "Anna.Andersson@hotmail.com", new ArrayList<>());

        Student henrik = new Student("Henrik Hansson", "Hemvägen 8",
                "Henrik.Hansson@gmail.com", new ArrayList<>());

        Student linda = new Student("Linda Larsson", "Larsbodavägen 36",
                "linda.lars@hmail.com", new ArrayList<>());

        Student niklas = new Student("Niklas Nilsson", "Nynäsvägen 6",
                "Niklas.Nilsson@hmail.com", new ArrayList<>());

        Student viktor = new Student("Viktor Vikholm", "Viknägatan 3",
                "virre.viks@hmail.com", new ArrayList<>());


        Lärare håkan = new Lärare("Håkan Olofsson", "Arbottnavägen 18",
                "hakan.olof@gmail.com", new ArrayList<>());

        Lärare birgitta = new Lärare("Birgitta Holm", "Lundagatan 11",
                "Birgitta.Holm", new ArrayList<>());



        programmering1.setTeacher(håkan);
        programmering2.setTeacher(håkan);
        svenska1.setTeacher(birgitta);

        programmering1.getStudents().add(anna);
        programmering1.getStudents().add(henrik);
        programmering2.getStudents().add(linda);
        programmering2.getStudents().add(niklas);
        programmering2.getStudents().add(viktor);
        svenska1.getStudents().add(anna);
        svenska1.getStudents().add(henrik);
        svenska1.getStudents().add(linda);
        svenska1.getStudents().add(niklas);
        svenska1.getStudents().add(viktor);

        System.out.println();
        printClassList(svenska1);
        System.out.println();
        printClassList(programmering1);
        System.out.println();
        printClassList(programmering2);
    }

    public static void main(String[] args) {

        Sprint1.Skola.Huvudprogram h = new Sprint1.Skola.Huvudprogram();
        h.huvudprogram();
    }


}
