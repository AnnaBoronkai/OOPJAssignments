package Sprint1.SkolaArrayList;
import java.util.*;

    public class Lärare extends Person {

        private ArrayList<Kurs> teachingCourses;

        public Lärare(String name, String address, String email, ArrayList<Kurs> teachingCourses) {
            super(name, address, email);
            this.teachingCourses = teachingCourses;
        }

        public ArrayList<Kurs> getTeachingCourses() {
            return teachingCourses;
        }

        public void setTeachingCourses(ArrayList<Kurs> teachingCourses) {
            this.teachingCourses = teachingCourses;
        }
    }
