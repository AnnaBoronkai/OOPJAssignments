package Sprint1.Bilregister;

public class Bilägare extends Person {

   public Bilägare(String name, String address, int age) { //Konstruktor Bilägare (som ärver Persons instansvariabler)
        super(name, address, age);//superkonstruktor

   }



}




