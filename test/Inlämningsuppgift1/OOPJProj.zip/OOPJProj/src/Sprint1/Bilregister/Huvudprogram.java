package Sprint1.Bilregister;

public class Huvudprogram {

    private void printCar(Bil car){
        System.out.println();
        System.out.println("Bilen är en " + car.getBrand() + " " + car.getModel() +
                " med registreringsnummer " + car.getRegisterNumber());
        if (car.getOwner() == null)
            System.out.println("Bilen har ingen ägare.");
        else {
            System.out.println("Den ägs av " + car.getOwner().getName() + " som är " +
                    car.getOwner().getAge() + " år och bor på " + car.getOwner().getAddress() + ".");
        }
    }

    public void huvudprogram(){ //Varför?? Sigrun har inget void här

        Bil gråVolvo = new Bil("ORB 849", "Volvo", "740");
        Bil rödSkoda = new Bil("SKE 904", "Skoda", "Octavia");
        Bil svartAudi = new Bil("UYS 351", "Audi", "A3");


        Bilägare Lars = new Bilägare("Lars Hansson", "Cirkelvägen 8", 7);
        Bilägare Hanna = new Bilägare("Hanna Lind", "Blekingegatan 19", 39);
        Bilägare Alex = new Bilägare("Alex Wik", "Stockholmsvägen 68", 25);

        gråVolvo.setOwner(Lars);
        rödSkoda.setOwner(Hanna);
        svartAudi.setOwner(Lars);

        gråVolvo.sold();
        gråVolvo.setOwner(Hanna);

        rödSkoda.sold();
        rödSkoda.setOwner(Lars);

        svartAudi.sold();
        svartAudi.setOwner(Alex);

        printCar(gråVolvo);
        printCar(rödSkoda);
        printCar(svartAudi);


    }

    public static void main(String[] args) {
        Huvudprogram h = new Huvudprogram();

        h.huvudprogram();

    }
}
