package Sprint1.Bilregister;

public class Bil {

    protected String registerNumber;//instansvariabel
    protected String brand;//instansvariabel
    protected String model;//instansvariabel
    protected Bilägare owner;//  instansvariabel med variabeltyp från klassen Bilägare

    //Bil har en instansvariabel Bilägare owner;


    public Bil(String registerPlate, String brand, String model){
        this.registerNumber = registerPlate;
        this.model = model;
        this.brand = brand;

    }
    public Bil (){}//Default-konstruktor


    public String getRegisterNumber() {

        return registerNumber;
    }

    public void setRegisterNumber(String registerNumber) {
        this.registerNumber = registerNumber;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public Bilägare getOwner() { //hämta uppgift om en ett bil-ojekts ägare
        return owner;
    }

    public void sold(){ //nollställ bil-ojektets ägare om bilen säljs
        owner = null;
    }


    public void setOwner(Bilägare owner){ //ge ett bil-objekt en ägare om den köps
        this.owner = owner;
    }


}


