package Sprint1.Bilregister;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class HuvudprogramTest {

    @Test
    void huvudprogram() {
    }

    @Test
    void main() {
    }
}