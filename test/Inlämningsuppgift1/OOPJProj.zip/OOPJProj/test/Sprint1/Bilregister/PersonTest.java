package Sprint1.Bilregister;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PersonTest {

   Person person1 = new Person();
   Person person2 = new Person();



 @Test
    void getName() {
    }

    @Test
    void setName() {

    }

    @Test
    void getAddress() {
    }

    @Test
    void setAddress() {
    }

    @Test
    void getAge() {
    }

    @Test
    void setAge() {
    }
}