package Sprint1.Bilregister;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class BilTest {

    public Bil  bil1 = new Bil("891 KJH", "Honda", "bla");
    Bil bil2 = new Bil();

/*

    @Test
    void getRegisterNumber() {
        String exRegisterPlate = "891 KJH";
        String actualRegisterPlate = bil1.getRegisterNumber();

        Assertions.assertEquals(exRegisterPlate, actualRegisterPlate);
    }

    @Test
    void setRegisterNumber() {
        String oldNr = "891 KJH";
        String newNr = bil1.setRegisterNumber();

        Assertions.assertEquals(oldNr, newNr);

    } */

    @Test
    void getModel() {
    }

    @Test
    void setModel() {
    }

    @Test
    void getBrand() {
    }

    @Test
    void setBrand() {
    }

    @Test
    void getOwner() {
    }

    @Test
    void sold() {
    }

    @Test
    void setOwner() {

    }
}