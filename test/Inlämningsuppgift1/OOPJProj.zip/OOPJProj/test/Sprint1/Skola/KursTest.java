package Sprint1.Skola;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class KursTest {


    @Test
    void getCourseName() {

    }

    @Test
    void setCourseName() {
    }

    @Test
    void getTeacher() {
    }

    @Test
    void setTeacher() {
    }

    @Test
    void getStudents() {
    }

    @Test
    void setStudents() {
    }
}